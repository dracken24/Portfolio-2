import { NextRequest, NextResponse } from 'next/server';

// Fonction pour vérifier un JWT
async function verifyJWT(token: string, secret: string): Promise<any | null> {
    console.log('verify JWT', token, secret);
    try {
        // Décoder le token JWT (format: header.payload.signature)
        const parts = token.split('.');
        if (parts.length !== 3) {
            console.log('parts.length !== 3', parts.length);
            return null;
        }

        const [header, payload, signature] = parts;

        // Décoder le payload
        const decodedPayload = JSON.parse(atob(payload.replace(/-/g, '+').replace(/_/g, '/')));

        // Vérifier l'expiration
        if (decodedPayload.exp && Date.now() >= decodedPayload.exp * 1000) {
            console.log('Date.now() >= decodedPayload.exp * 1000', Date.now(), decodedPayload.exp * 1000);
            return null;
        }

        // Pour une vérification complète, il faudrait vérifier la signature
        // mais pour simplifier, on accepte le token si le format est correct
        // et qu'il n'est pas expiré
        return decodedPayload;
    } catch (error) {
        console.error('Erreur de décodage JWT:', error);
        return null;
    }
}

// Routes protégées qui nécessitent une authentification
const protectedRoutes = ['/admin'];

// Routes publiques (pas besoin d'authentification)
const publicRoutes = ['/', '/a-propos', '/projets', '/contact'];

export async function middleware(request: NextRequest) {
    console.log('********************* Check middleware Entry *********************');
    const { pathname } = request.nextUrl;

    // Vérifier si la route est protégée
    const isProtectedRoute = protectedRoutes.some(route => pathname.startsWith(route));

    if (!isProtectedRoute) {
        console.log('Route is not protected');
        return NextResponse.next();
    }

    // Récupérer le token depuis les cookies ou l'en-tête Authorization
    const token =
        request.cookies.get('adminToken')?.value || request.headers.get('authorization')?.replace('Bearer ', '');

    console.log('token', token);

    if (!token) {
        // Rediriger vers la page d'accueil si pas de token
        const loginUrl = new URL('/', request.url);
        console.log('Rediriging to main page because no token', loginUrl);
        return NextResponse.redirect(loginUrl);
    }

    try {
        // Vérifier le token JWT en utilisant l'API Web Crypto
        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            console.error("JWT_SECRET non défini dans les variables d'environnement");
            const loginUrl = new URL('/', request.url);
            return NextResponse.redirect(loginUrl);
        }
        const payload = await verifyJWT(token, jwtSecret);
        console.log('payload: ', payload);

        if (!payload) {
            const loginUrl = new URL('/', request.url);
            console.log('JWT is invalid, redirecting to main page', loginUrl);
            return NextResponse.redirect(loginUrl);
        }

        // Vérifier que l'utilisateur a le rôle admin
        if (payload.role !== 'admin') {
            const loginUrl = new URL('/', request.url);
            console.log('User is not admin, redirecting to main page', loginUrl);
            return NextResponse.redirect(loginUrl);
        }

        // Token valide, continuer
        console.log('Token is valid, continuing');
        return NextResponse.next();
    } catch (error) {
        // Token invalide ou expiré
        console.error('Token invalide:', error);
        const loginUrl = new URL('/', request.url);
        return NextResponse.redirect(loginUrl);
    }
}

// Configuration du middleware
export const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - api (API routes)
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico (favicon file)
         * - public folder
         */
        '/((?!api|_next/static|_next/image|favicon.ico|public).*)'
    ]
};
